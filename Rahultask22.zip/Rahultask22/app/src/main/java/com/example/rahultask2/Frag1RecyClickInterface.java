package com.example.rahultask2;

public interface Frag1RecyClickInterface {
    void onItemClick(int pos ,String text,boolean clicked);
}

